import sys
import ws_utils


def main(): 
    filename = sys.argv[1]
    grid = [] 
    with open(filename, "r") as file:
        #makes every letter in the file lowercase 
        grid = [list(map(str.lower, i.split())) for i in file.readlines()]

    targets = [] 
    #repeatedly query for words the user would like to see the solution of 
    print("Enter a word and press enter for however many words you'd like. If found in the grid file you provided, the solution will be piped to a unique file")
    while True:
        response = input("Please enter a word you'd like to be highlighted (q to quit): ")
        if response != "q": 
            #sanitize input
            targets.append(response.strip().lower())
        else: 
            break
        
    results = []
    for t in targets: 
        results = ws_utils.wordsearch(t, grid)
        with open(f"results_of_{t}.txt", "w+") as file: 
            if len(results) == 0: 
                file.write(f"'{t}' not found in {filename}")
            else:
                for res in results:
                    file.write(" ".join(res))  
                    file.write("\n") 
        
if __name__ == "__main__": 
    main()