import copy

def left_up(coords1: tuple, coords2: tuple, matrix: list) -> bool: 
    """Checks if the element at `coords1` in `lst` is immediately to the left and up of that
    at `coords2`"""
    if coords1[0] < 0 or coords1[1] < 0:
        return False
    return coords1[0] == coords2[0]-1 and coords1[1] == coords2[1]-1

def left_of(coords1: tuple, coords2: tuple, matrix: list) -> bool:
    """Checks if the element at `coords1` in `lst` is immediately to the left of that
    at `coords2`"""
    if coords1[1] < 0:
        return False
    return coords1[0] == coords2[0] and coords1[1] == coords2[1]-1   

def left_down(coords1: tuple, coords2: tuple, matrix: list) -> bool: 
    """Checks if the element at `coords1` in `lst` is immediately to the left and down of that
    at `coords2`"""
    if coords1[1] < 0 or coords1[0] >= len(matrix[0]):
        return False
    return coords1[0] == coords2[0]+1 and coords1[1] == coords2[1]-1

def right_up(coords1: tuple, coords2: tuple, matrix: list) -> bool: 
    """Checks if the element at `coords1` in `lst` is immediately to the right and up of that
    at `coords2`"""
    if coords1[0] < 0 or coords1[1] >= len(matrix[0]):
        return False
    return coords1[0] == coords2[0]-1 and coords1[1] == coords2[1]+1

def right_of(coords1: tuple, coords2: tuple, matrix: list) -> bool:
    """Checks if the element at `coords1` in `lst` is immediately to the right of that
    at `coords2`"""
    if coords1[1] >= len(matrix[0]):
        return False
    return coords1[0] == coords2[0] and coords1[1] == coords2[1]+1   

def right_down(coords1: tuple, coords2: tuple, matrix: list) -> bool: 
    """Checks if the element at `coords1` in `lst` is immediately to the right and down of that
    at `coords2`"""
    if coords1[0] >= len(matrix) or coords1[1] > len(matrix[0]):
        return False
    return coords1[0] == coords2[0]+1 and coords1[1] == coords2[1]+1

def above(coords1: tuple, coords2: tuple, matrix: list) -> bool: 
    """Checks if the element at `coords1` in `lst` is immediately above that
    at `coords2`"""
    if coords1[0] < 0:
        return False
    return coords1[0] == coords2[0]-1 and coords1[1] == coords2[1]

def below(coords1: tuple, coords2: tuple, matrix: list) -> bool: 
    """Checks if the element at `coords1` in `lst` is immediately above that
    at `coords2`"""
    if coords1[0] >= len(matrix):
        return False
    return coords1[0] == coords2[0]+1 and coords1[1] == coords2[1]

def adjacent(coords1: tuple, coords2: tuple, matrix: list) -> bool: 
    """Checks if the element at `coords1` in `lst` is immediately adjacent to that
    at `coords2`"""
    return left_up(coords1, coords2, matrix) or left_of(coords1, coords2, matrix) or left_down(coords1, coords2, matrix) or \
        right_up(coords1, coords2, matrix) or right_of(coords1, coords2, matrix) or right_down(coords1, coords2, matrix) or \
        above(coords1, coords2, matrix) or below(coords1, coords2, matrix)

def adjacency_list(coords: tuple, matrix: list) -> list:
    """returns a list of every tuple such that the element at its coordinates is 
    adjacent to that at `coords` in `matrix`"""
    lst = [] 
    for i in range(len(matrix)): 
        for j in range(len(matrix[0])):
            if len(lst) == 8: 
                break
            if adjacent((i, j), coords, matrix): 
                lst.append((i, j))
    return lst

def valid_tuple(coords: tuple, matrix: list) -> bool:
    """checks if a set of coords are in the matrix """
    return not(coords[0] < 0 or coords[0] >= len(matrix) or coords[1] < 0 or coords[1] >= len(matrix[0]))

def pathfinding(target: str, start: tuple, matrix: list) -> list: 
    """Given the first letter of a target string which is at
    #`start` in `matrix, attempts to find every 
    tuple of indices such that they form a straight line and `matrix[tuple]` is
    a letter of `target`"""
    if len(target) == 1 or len(target) == 0: 
        return []
    indices = [] 
    indices.append(start)
    adj_list = adjacency_list(start, matrix)
    #get a list of the actual letters in the adjacency of target[0] 
    letters = [matrix[i][j] for (i, j) in adj_list]
    #a list of coords, each of which have the second letter of the word in them 
    coords = []
    if target[1] not in letters: 
        return [] 
    for i in adj_list: 
        if matrix[i[0]][i[1]] == target[1]: 
            #gets the coords of target[1]
            coords.append(i)
    
    #we've already found target[0] at `start` and know that target[1] is in its
    #adjacency list. We now want target[1:]
    #for each potential solution, add indices pairs to indices in the chosen direction until
    #the array bounds have been reached or the full target word has been recorded via index pairs
    for coord in coords:   
        if (left_up(coord, start, matrix)):
            indices.append(coord)
            # -2 because the first two letters have already been added 
            for i in range(len(target)-2):
                #does bounds checking and makes sure every character of `target` is actually being found
                if valid_tuple( (coord[0]-(i+1), coord[1]-(i+1)), matrix ) and \
                    target[2+i] == matrix[coord[0]-(i+1)][coord[1]-(i+1)]: 
                    indices.append( (coord[0]-(i+1), coord[1]-(i+1)) )
            #if the right path has been chosen, return that path
            if len(indices) == len(target): 
                return indices
            #else reset the path back to the coords of the first letter 
            else: 
                indices = indices[:1] 

        elif (left_of(coord, start, matrix)):
            indices.append(coord)
            # -2 because the first two letters have already been added 
            for i in range(len(target)-2):
                #does bounds checking and makes sure every character of `target` is actually being found
                if valid_tuple( (coord[0], coord[1]-(i+1)), matrix ) and \
                    target[2+i] == matrix[coord[0]][coord[1]-(i+1)]: 
                    indices.append( (coord[0], coord[1]-(i+1)) )
            #if the right path has been chosen, return that path
            if len(indices) == len(target): 
                return indices
            #else reset the path back to the coords of the first letter 
            else: 
                indices = indices[:1] 

        elif (left_down(coord, start, matrix)):
            indices.append(coord)
            # -2 because the first two letters have already been added 
            for i in range(len(target)-2):
                #does bounds checking and makes sure every character of `target` is actually being found
                if valid_tuple( (coord[0]+(i+1), coord[1]-(i+1)), matrix ) and \
                    target[2+i] == matrix[coord[0]+(i+1)][coord[1]-(i+1)]: 
                    indices.append( (coord[0]+(i+1), coord[1]-(i+1)) )
            #if the right path has been chosen, return that path
            if len(indices) == len(target): 
                return indices
            #else reset the path back to the coords of the first letter 
            else: 
                indices = indices[:1] 

        elif (right_up(coord, start, matrix)):
            indices.append(coord)
            # -2 because the first two letters have already been added 
            for i in range(len(target)-2):
                #does bounds checking and makes sure every character of `target` is actually being found
                if valid_tuple( (coord[0]-(i+1), coord[1]+(i+1)), matrix ) and \
                    target[2+i] == matrix[coord[0]-(i+1)][coord[1]+(i+1)]: 
                    indices.append( (coord[0]-(i+1), coord[1]+(i+1)) )
            #if the right path has been chosen, return that path
            if len(indices) == len(target): 
                return indices
            #else reset the path back to the coords of the first letter 
            else: 
                indices = indices[:1] 

        elif (right_of(coord, start, matrix)):
            indices.append(coord)
            # -2 because the first two letters have already been added 
            for i in range(len(target)-2):
                #does bounds checking and makes sure every character of `target` is actually being found
                if valid_tuple( (coord[0], coord[1]+(i+1)), matrix ) and \
                    target[2+i] == matrix[coord[0]][coord[1]+(i+1)]: 
                    indices.append( (coord[0], coord[1]+(i+1)) )
            #if the right path has been chosen, return that path
            if len(indices) == len(target): 
                return indices
            #else reset the path back to the coords of the first letter 
            else: 
                indices = indices[:1] 

        elif (right_down(coord, start, matrix)):
            indices.append(coord)
            # -2 because the first two letters have already been added 
            for i in range(len(target)-2):
                #does bounds checking and makes sure every character of `target` is actually being found
                if valid_tuple( (coord[0]+(i+1), coord[1]+(i+1)), matrix ) and \
                    target[2+i] == matrix[coord[0]+(i+1)][coord[1]+(i+1)]: 
                    indices.append( (coord[0]+(i+1), coord[1]+(i+1)) )
            #if the right path has been chosen, return that path
            if len(indices) == len(target): 
                return indices
            #else reset the path back to the coords of the first letter 
            else: 
                indices = indices[:1] 
        
        elif (above(coord, start, matrix)):
            indices.append(coord)
            # -2 because the first two letters have already been added 
            for i in range(len(target)-2):
                #does bounds checking and makes sure every character of `target` is actually being found
                if valid_tuple( (coord[0]-(i+1), coord[1]), matrix ) and \
                    target[2+i] == matrix[coord[0]-(i+1)][coord[1]]: 
                    indices.append( (coord[0]-(i+1), coord[1]) )
            #if the right path has been chosen, return that path
            if len(indices) == len(target): 
                return indices
            #else reset the path back to the coords of the first letter 
            else: 
                indices = indices[:1]

        elif (below(coord, start, matrix)):
            indices.append(coord)
            # -2 because the first two letters have already been added 
            for i in range(len(target)-2):
                #does bounds checking and makes sure every character of `target` is actually being found
                if valid_tuple( (coord[0]+(i+1), coord[1]), matrix ) and \
                    target[2+i] == matrix[coord[0]+(i+1)][coord[1]]: 
                    indices.append( (coord[0]+(i+1), coord[1]) )
            #if the right path has been chosen, return that path
            if len(indices) == len(target): 
                return indices
            #else reset the path back to the coords of the first letter 
            else: 
                indices = indices[:1]  
    return indices 




def wordsearch(target: str, matrix: list) -> list: 
    """Returns a list-of-strings representation of the a list altered from `matrix`
    such that the letters in `target` in it, if found, are capitalized and surrounded by quotation marks"""
    if len(target) == 0 or len(target) == 1: 
        return []
    solution = [] 
    final_indices = []
    for i in range(len(matrix)): 
        for j in range(len(matrix[0])):
            #find first character
            if matrix[i][j] == target[0]: 
                index_pairs = pathfinding(target, (i, j), matrix)
                if len(index_pairs) < len(target): 
                    continue
                else: 
                    final_indices = index_pairs
                    break
    #for future reference: prevents aliasing (`solution = matrix` would cause `matrix` to be altered in place)
    solution = copy.deepcopy(matrix)
    #solution = matrix
    #no solution found, i.e. `target` isn't in `matrix` or its just a single letter, both fail states
    if len(final_indices) == 0 or len(final_indices) == 1: 
        return []
    #capitalize and surround with quotations each letter in `target` in the solution
    for pair in final_indices:
        solution[pair[0]][pair[1]] = f"'{solution[pair[0]][pair[1]].upper()}'"
    return solution